#ifndef INVENTORY_H
#define INVENTORY_H

class Inventory
{
public:
    Inventory();
    ~Inventory();

};

#endif // INVENTORY_H
