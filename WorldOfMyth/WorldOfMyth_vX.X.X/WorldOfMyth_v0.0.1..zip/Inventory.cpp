#include "Inventory.h"

Inventory::Inventory()
{
}

Inventory::~Inventory()
{
    //delete backpacks;
}

