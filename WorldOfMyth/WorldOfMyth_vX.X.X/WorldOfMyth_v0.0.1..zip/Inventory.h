#ifndef INVENTORY_H
#define INVENTORY_H

class Inventory
{
    
private:
    
    //vector<Backpack> backpacks;
    
public:
    Inventory();
    ~Inventory();

};

#endif // INVENTORY_H
