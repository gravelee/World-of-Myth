#include "ItemSlotList.h"

ItemSlotList::ItemSlotList()
{
}

ItemSlotList::~ItemSlotList()
{
}

