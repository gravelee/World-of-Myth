#ifndef _ITEMSLOTLIST_H_
#define _ITEMSLOTLIST_H_

class ItemSlotList
{
    
    
public:
    ItemSlotList();
    ~ItemSlotList();

};

#endif
